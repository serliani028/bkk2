<div class="row">
<div class="col-md-12">
  <div class="box box-solid">
    <div class="box-body">
    	<p><?php echo esc_output($job['description'], 'raw'); ?></p>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</div>
<!-- ./col -->
</div>